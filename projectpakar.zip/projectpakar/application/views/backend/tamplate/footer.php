<footer class="main-footer">
    <strong>Copyright &copy; 2023 <a href="https://www.instagram.com/hasbi_farhan30/">Farhan</a></strong>
</footer>