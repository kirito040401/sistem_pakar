<footer>
    <div class="text-center p-4 bg-info text-white fixed-buttom">
        <strong>Copyright &copy; 2023 <a class="text-white" href="https://www.instagram.com/hasbi_farhan30/">Farhan</a></strong>
    </div>
</footer>