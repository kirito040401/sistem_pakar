<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Sistem Pakar Hama Anggrek Coelogyne Pandurata</title>
</head>
<!-- tutup my css -->

<body class="mt-5">
    <!-- navbar -->
    <?php $this->load->view("frondend/tamplate/navbar");?>

    <!-- Informasi Penyakit -->
    <section id="informasi_penyakit" class="informasi_penyakit">
        <div class="container">
            <br><br>
            <h2 height="500px" id="Informasi_Penyakit" class="text-center mb-5">Informasi Penyakit</h2>
            <div class="row mb-1">
                <div class="col-3">
                    <img src="<?php echo base_url() ?>assets/Gambar/foto_frondend/bunga.jpg"
                        style="height:300px; weidht:250px" class="img-thumbnail">
                </div>
                <div class="col-9">
                    <p class="text-justify">Hama adalah organisme yang memiliki 
                        sifat merugikan bagi objek yang dihinggapi dan memiliki sifat invasive 
                        sehingga dapat menimbulkan kerusakan pada ekosistem. Hama juga dapat menjadi suatu penyebaran penyakit pada tanaman. 
                        Hama sering kali kita dengar pada dunia pertanian tetapi hama juga menyerang banyak sektor lain termasuk budidaya tanaman Angrek Coelogyne Pandurata.
                        Tanaman Anggrek Coelogyne Pandurata, yaitu tanaman Anggrek Hitam. Tanaman Anggrek Hitam merupakan tanaman yang berasal dari Pulau Kalimantan, 
                        nama anggrek hitam diberikan karena bunga anggrek ini memiliki tanda hitam pada bibirnya yang membentang ke belakang sampai bagian dalam bunga 
                        dan Mahkota bunga dan kelopak bunga Anggrek Hitam berwarna hijau cerah.
                    </p>
                    <!-- <p class="text-justify">Terdapat dampak gejala
                        stunting jangka pendek meliputi hambatan perkembangan, penurunan fungsi kekebalan, penurunan
                        fungsi kognitif, dan gangguan sistem pembakaran. Sedangkan dampak gejala jangka panjang meliputi
                        obesitas, penurunan toleransi glukosa, penyakit jantung koroner, hipertensi, dan osteoporosis.
                        Pada kasus seperti ini orang tua sangat berperan penting pada pola asuh anak.
                    </p> -->
                    <!-- <p class="text-justify">Oleh karena itu orang tua dapat melakukan evaluasi atau monitoring balita
                        melalui
                        faktor penyebab terjadinya stunting terutama di usia 0-24 bulan sehingga dapat mencegah
                        terjadinya rawan
                        stunting secara dini.
                    </p> -->
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-12">
                    <a href="<?php echo base_url("Frondend/frondend/biodata")?>"><button type="button"
                            class="btn btn-primary btn-sm float-right">Mulai Konsultasi
                        </button>
                    </a>
                </div>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr class="table-info">
                        <th scope="col" class="text-center">NO</th>
                        <th scope="col" class="text-center">Penyakit</th>
                        <th scope="col" class="text-center">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row" class="text-center">1</th>
                        <td width="180px" class="text-center">Hama Kumbang Gajah</td>
                        <td>hama yang memakan bagian epidermis tanaman,
                            jika sampai pada titik tumbuh tanaman maka dapat menyebabkan kematian. </td>
                    </tr>
                    <tr>
                        <th scope="row" class="text-center">2</th>
                        <td class="text-center">Hama Kutu Perisai</td>
                        <td>hama yang menyerang bagian daun terutama pada permukaan bawah daun,
                            dan menimbulkan bercak hitam dan merusak daun hingga berlubang.</td>
                    </tr>
            </table>

        </div>
    </section>
    <!-- Informasi Penyakit-->


    <!-- footer -->
    <?php $this->load->view("frondend/tamplate/footer");?>
    <!-- footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
</body>

</html>