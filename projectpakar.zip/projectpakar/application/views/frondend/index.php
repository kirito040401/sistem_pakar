<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Sistem Pakar Hama Anggrek Coelogyne Pandurata</title>
</head>
<!-- tutup my css -->

<body class="mt-5">
    <!-- navbar -->
    <?php $this->load->view("frondend/tamplate/navbar");?>
    <!-- jumbotron -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container text-center">
            <img src="<?php echo base_url() ?>assets/Gambar/foto_frondend/bunga.jpg" class="img-fluid rounded"
                width="25%" alt="Responsive image">
            <!-- <style type="text/css">
				.jumbotron {
					position: relative;
					background: url(img/bg3.png) center center;
					color: currentColor;
					width: 100%;
					height: 100%;
					background-size: cover;
					overflow: hidden;
				}
			</style> -->
            <h1 class="display-7 mt-4" height="100%" width="30%">DIAGNOSA HAMA ANGGREK COELOGYNE PANDURATA</h1>
            <p>Selamat Datang, Website ini dapat membantu anda untuk mengetahui tentang pengetahuan Anggrek Coelogyne 
                Pandurata dalam diagnosa serangan hama yang terjadi pada anggrek hitam</p>
            <!-- <button class="btn btn-danger me-md-2 mt-5" type="button">Mulai Konsultasi</button> -->
        </div>
    </div>
    <!-- tutup jumbotron -->

    <!-- menu -->
    <section id="menu" class="menu">
        <div class="container">
            <div class="row mb-5">
                <!-- <div class="col text-center">
                    <h2>Menu Utama</h2>
                </div> -->
            </div>
            <div class="row">
                <div class="col-md">
                    <div class="card">
                        <!-- <img class="card-img-top" src="img/aboutus.jpeg" alt="Card image cap"> -->
                        <div class="card-body">
                            <h5 class="card-title">Tentang</h5>
                            <p class="card-text">Sistem Pakar Diagnosa Hama Anggrek.</p>
                            <a href="#tentang">
                                <button type="button" class="btn btn-outline-primary">Tekan Disini</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="card">
                        <!-- <img class="card-img-top" src="img/info.jpg" alt="Card image cap"> -->
                        <div class="card-body">
                            <h5 class="card-title">Informasi Hama Penyakit</h5>
                            <p class="card-text">Informasi Hama Anggrek Hitam.</p>
                            <a href="<?php echo base_url("Frondend/frondend/informasi_penyakit")?>">
                                <button type="button" class="btn btn-outline-primary">Tekan Disini</button></a>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="card">
                        <!-- <img class="card-img-top" src="img/dokter.jpg" alt="Card image cap"> -->
                        <div class="card-body">
                            <h5 class="card-title">Diagnosa</h5>
                            <p class="card-text">Mulai untuk Konsultasi.</p>
                            <a href="<?php echo base_url("Frondend/frondend/biodata")?>">
                                <button type="button" class="btn btn-outline-primary">Tekan Disini</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- tutup menu -->

    <!-- tentang -->
    <section id="tentang" class="tentang">
        <div class="container">
            <div class="row mb-5"></div>
            <div class="row mb-6">
                <div class="col text-center">
                    <h2>Tentang</h2>
                    <p class="text-justify">Penerapan Metode Certainty Factor dan Case Based Reasoning Pada Sistem Pakar
                        Diagnosa Hama Anggrek Coelogyne Pandurata, dengan adanya sistem ini semoga dapat membantu banyak
                        orang untuk mengetahui tentang pengetahuan penyakit hama pada tanaman Anggrek Hitam. </p>
                </div>
            </div>
        </div>
    </section>
    <!-- tutup tentang-->

    <!-- WHO -->
    <section id="tentang" class="tentang">
        <div class="container">
            <div class="row mb-5"></div>
            <div class="row mb-6">
                <div class="col text-center">
                    <h2>Keadaan Populasi Anggrek Coelogyne Pandurata</h2>
                    <p class="text-justify">(Di bawah ini akan menampilkan keadaan Populasi Anggrek Coelogyne Pandurata
                        di Barito Timur) :</p>
                    <iframe src="https://sindikasi.republika.co.id/berita/pn3mnx384/network" width="100%"
                        height="400px"></iframe>
                </div>
            </div>
        </div>
    </section>
    <!-- WHO -->

    <!-- KKRI -->
    <!-- <section id="tentang" class="tentang">
        <div class="container">
            <div class="row mb-5"></div>
            <div class="row mb-7">
                <div class="col text-center">
                    <h2>Prevalensi Stunting</h2>
                    <p class="text-justify">Di bawah ini akan menampilkan keadaan atau prevalensi stunting di Indonesia
                        menurut Kementerian Kesehatan Republik Indonesia :</p>
                    <iframe src="https://sigiziterpadu.kemkes.go.id/ppgbm/index.php/Dashboard/stunting" width="100%"
                        height="400px"></iframe>
                </div>
            </div>
        </div>
    </section> -->
    <!-- KKRI -->

    <!-- status gizi -->
    <!-- <section id="tentang" class="tentang">
        <div class="container">
            <div class="row mb-5"></div>
            <div class="row mb-7">
                <div class="col text-center">
                    <h2>Status Gizi</h2>
                    <p class="text-justify">Di bawah ini akan menampilkan keadaan status gizi di Indonesia
                        menurut Kementerian Kesehatan Republik Indonesia :</p>
                    <iframe src="https://sigiziterpadu.kemkes.go.id/ppgbm/index.php/Dashboard/" width="100%"
                        height="400px"></iframe>
                </div>
            </div>
        </div>
    </section> -->
    <!-- status gizi -->

    <!-- Informasi Penyakit -->

    <p style="margin-button 50px;"></p>
    <!-- Informasi Penyakit-->


    <!-- footer -->
    <?php $this->load->view("frondend/tamplate/footer");?>
    <!-- footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
</body>

</html>